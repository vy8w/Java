package abc;

public class A {
	public int a;
	protected int b;
	int c;
	private int d;
	
	void abc() {
		//멤버사용 (a,b,c,d)
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
}