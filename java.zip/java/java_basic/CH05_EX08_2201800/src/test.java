
public class test {
	public static void main(String[] ar) {
		//넘어온 메인메서드 매개변수 길이 확인하기
		System.out.println(ar.length);
		
//		int[] a = new int[0];
//		System.out.println(a.length);
		
		System.out.println(ar[0]); //abc
		System.out.println(ar[1]); //bcd
		System.out.println(ar[2]); //2 -> 숫자가 아니라 문자열 "2"
		System.out.println(ar[3]); //3.5 -> 숫자가 아니라 문자열 "3"
		
		System.out.println(ar[2]+1); //21
		System.out.println(ar[3]+1.2); //3.51.2
		
		//String --> 기본자료형
		//Boolean, Byte, Short, Integer, Long, Float, Double, Character
		
		System.out.println(Integer.parseInt(ar[2])+1); //3
		//-> integer로 하면 2가 정수(숫자) 2로 바뀜
		System.out.println(Double.parseDouble(ar[3])+1.2); //3.51.2
	}
}
