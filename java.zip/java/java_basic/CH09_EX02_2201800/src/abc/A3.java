public class A3 {
	A3(){
		
	}
}

package bcd;
import abc.A1; //(O)

public class B1 {
	void bcd(){
		A1 a1 = new A1();
	}
	
}