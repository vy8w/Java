package abc;

public class A2 {

}
