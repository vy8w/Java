public class A1 {
	//컴파일러가 자동으로 생성해주는 생성자
	//public A1() {}
}