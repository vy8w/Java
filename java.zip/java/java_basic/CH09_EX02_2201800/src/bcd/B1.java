package bcd;

public class B1 {

}
