package bcd;
//import abc.A2; //(X) 

public class B2 {

}

package bcd;
import abc.A3; //(O)
public class B3 {
	void bcd() {
		A3 a3 = new A3();
	}
}