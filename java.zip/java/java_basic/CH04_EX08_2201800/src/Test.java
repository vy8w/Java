//예제

public class Test {
	public static void main(String[] args) {
		//continue 제어키워드
		//다음코드에서 출력의 횟수를 써라.
		for(int i=0; i<10; i++) { // 6번 
			if(i>5) {
				continue;
			}
			System.out.println(i);
		}
		
		for(int i=0; i<10; i++) { // 6번 
			System.out.println(i);
			if(i==6) {
				continue;
			}	
		}
		
		for(int i=0; i<5; i++) { // 15번 
			for(int j=0; j<4; j++) {
				if(j==2) {
					continue;
				}
				System.out.println("A");
			}
		}
		
		for(int i=0; i<5; i++) { // 16번 
			for(int j=0; j<4; j++) {
				if(i==2) {
					continue;
				}
				System.out.println("b");
			}
		}
		
		for(int i=0; i<5; i++) { // 12번 
			for(int j=0; j<4; j++) {
				if(i==1 || j==2) {					
					continue;
				}
				System.out.println("c");
			}
		}
		
		for(int i=0; i<5; i++) { // 3번 
			for(int j=0; j<4; j++) {
				if(j==2) {		
					i=10;
					continue;
				}
				System.out.println("d");
			}
		}
		
		abc: for(int i=0; i<5; i++) { // 10번 
			for(int j=0; j<4; j++) {
				if(j==2) {					
					continue abc;
				}
				System.out.println("e");
			}
		}
		
	}
}