package cde.def;

public class B {

}
