
public class Test {
	//main메서드 만들기 (한 줄 주석)
	public static void main(String[] ar) {
		//한 줄 출력
		System.out.println("안녕하세요");
		//실행명령어 ctrl+f11
	}
	
	
}
