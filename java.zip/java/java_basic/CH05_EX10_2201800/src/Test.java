//예제

import java.util.Arrays;

public class Test {
	public static void main(String[] args) {
		//String 메서드
		String a = "Hello Java Hello";
		//length()
		System.out.println(a.length());//16
		//chatAt()
		System.out.println(a.charAt(2));//1
		//indexOf(), lastIndexOf()
		System.out.println(a.indexOf("llo")); //2
		System.out.println(a.indexOf("llo", 5)); //13
		System.out.println(a.lastIndexOf("llo")); //13
		System.out.println(a.lastIndexOf("llo", 10)); //2
		//String.valueOf() : 기본자료형 -> 문자열 (정적(static) 메서드)
		System.out.println(String.valueOf(2.1)+3.3); //2.13.3
		//concat()
		System.out.println("안녕".concat("하세요")); //안녕하세요
		
		String b = "Hello Java"; 
		//toLowerCase(), toUpperCase()
		System.out.println(b.toLowerCase()); //hello java
		System.out.println(b.toLowerCase()); //hello java
		//repalce()
		System.out.println(b.replace("Hello", "안녕")); //안녕 Java
		//substring()
		System.out.println(b.substring(1,4)); //ell
		//split()
		String[] c = "abc,bcd,cde,def".split(",");
		System.out.println(Arrays.toString(c)); //[abc, bcd, cde, def]
		//trim()
		System.out.println("   abc   ".trim()); //abc
		
		//equals(), equalsIgnoreCase()
		String aa = new String("Java");
		String bb = new String("Java");
		String cc = new String("java");
		System.out.println(aa==bb); //false
		System.out.println(bb==cc); //false
		System.out.println(cc==aa); //false
		System.out.println(aa.equals(bb)); //true
		System.out.println(bb.equals(cc)); //false
		System.out.println(cc.equals(aa)); //false
		System.out.println(cc.equalsIgnoreCase(aa)); //true
		
		
		//
		
		
		
	}
}