class A{
	class D{
		
	}
	class E{
		class F{
			
		}
	}
}
class B{
	
}
public class Test {

}
class C{
	
}